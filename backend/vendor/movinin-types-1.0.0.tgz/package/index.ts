export enum UserType {
  Admin = 'ADMIN',
  Agency = 'AGENCY',
  User = 'USER',
  Tenant = 'TENANT',
}

// BTMS enums
export enum UnitStatus {
  Vacant = 'VACANT',
  Occupied = 'OCCUPIED',
  UnderMaintenance = 'UNDER_MAINTENANCE',
}

export enum FurnishingStatus {
  Unfurnished = 'UNFURNISHED',
  SemiFurnished = 'SEMI_FURNISHED',
  FullyFurnished = 'FULLY_FURNISHED',
}

export enum FurnishingCondition {
  New = 'NEW',
  Good = 'GOOD',
  NeedsRepair = 'NEEDS_REPAIR',
}

export enum RentStatus {
  Pending = 'PENDING',
  Paid = 'PAID',
  Partial = 'PARTIAL',
  Overdue = 'OVERDUE',
}

export enum MaintenancePriority {
  Low = 'LOW',
  Medium = 'MEDIUM',
  High = 'HIGH',
}

export enum MaintenanceStatus {
  Open = 'OPEN',
  InProgress = 'IN_PROGRESS',
  Completed = 'COMPLETED',
}

export enum AppType {
  Admin = 'ADMIN',
  Frontend = 'FRONTEND',
}

export enum PropertyType {
  Apartment = 'APARTMENT',
  Commercial = 'COMMERCIAL',
  Farm = 'FARM',
  House = 'HOUSE',
  Industrial = 'INDUSTRIAL',
  Plot = 'PLOT',
  Townhouse = 'TOWNHOUSE',
}

export enum BookingStatus {
  Void = 'VOID',
  Pending = 'PENDING',
  Deposit = 'DEPOSIT',
  Paid = 'PAID',
  Reserved = 'RESERVED',
  Cancelled = 'CANCELLED',
}

export enum RecordType {
  Admin = 'ADMIN',
  Agency = 'AGENCY',
  User = 'USER',
  Property = 'PROPERTY',
  Location = 'LOCATION',
  Country = 'COUNTRY',
}

export enum Availablity {
  Available = 'AVAILABLE',
  Unavailable = 'UNAVAILABLE',
}

export enum RentalTerm {
  Monthly = 'MONTHLY',
  Weekly = 'WEEKLY',
  Daily = 'DAILY',
  Yearly = 'YEARLY',
}

export enum PaymentGateway {
  PayPal = 'payPal',
  Stripe = 'stripe',
}

export interface SignUpPayload {
  email: string
  password: string
  fullName: string
  language: string
  active?: boolean
  verified?: boolean
  blacklisted?: boolean
  type?: string
  avatar?: string
  birthDate?: number | Date
  phone?: string
}

export interface CreateUserPayload {
  email?: string
  phone: string
  location: string
  bio: string
  fullName: string
  type?: string
  avatar?: string
  birthDate?: number | Date
  language?: string
  agency?: string
  password?: string
  verified?: boolean
  blacklisted?: boolean
  payLater?: boolean
}

export interface UpdateUserPayload extends CreateUserPayload {
  _id: string
  enableEmailNotifications?: boolean
  payLater?: boolean
}

export interface changePasswordPayload {
  _id: string
  password: string
  newPassword: string
  strict: boolean
}

export interface UpdateAgencyPayload {
  _id: string
  fullName: string
  phone: string
  location: string
  bio: string
  payLater: boolean
  blacklisted?: boolean
}

export interface UpdateStatusPayload {
  ids: string[]
  status: string
}

export interface Renter {
  _id?: string
  email: string
  phone: string
  fullName: string
  birthDate: string
  language: string
  verified: boolean
  blacklisted: boolean
}

export interface Booking {
  _id?: string
  agency: string | User
  property: string | Property
  renter?: string | User
  from: Date
  to: Date
  status: BookingStatus
  cancellation: boolean
  price?: number
  location: string | Location
  cancelRequest?: boolean
  sessionId?: string
  paymentIntentId?: string
  customerId?: string
  expireAt?: Date
  paypalOrderId?: string
}

export interface CheckoutPayload {
  renter?: User
  booking?: Booking
  payLater?: boolean
  sessionId?: string
  paymentIntentId?: string
  customerId?: string
  payPal?: boolean
}

export interface Filter {
  from?: Date
  dateBetween?: Date
  to?: Date
  location?: string
  keyword?: string
}

export interface GetBookingsPayload {
  agencies: string[]
  statuses: string[]
  user?: string
  property?: string
  filter?: Filter
  language?: string
}

export interface LocationName {
  language: string
  name: string
}

export interface CountryName {
  language: string
  name: string
}

export interface UpsertLocationPayload {
  country: string
  longitude?: number
  latitude?: number
  names: LocationName[]
  image?: string | null
  parentLocation?: string
}


export interface ActivatePayload {
  userId: string
  token: string
  password: string
}

export interface ValidateEmailPayload {
  email: string
}

export enum SocialSignInType {
  Facebook = 'facebook',
  Apple = 'apple',
  Google = 'google'
}

export interface SignInPayload {
  email?: string
  password?: string
  stayConnected?: boolean
  mobile?: boolean
  fullName?: string
  avatar?: string
  accessToken?: string
  socialSignInType?: SocialSignInType
}

export interface ResendLinkPayload {
  email?: string
}

export interface UpdateLanguage {
  id: string
  language: string
}

export interface ValidateAgencyPayload {
  fullName: string
}

export interface ValidateLocationPayload {
  language: string
  name: string
}

export interface ValidateCountryPayload {
  language: string
  name: string
}

export interface GetBookingPropertiesPayload {
  agency: string
  location: string
}

export interface User {
  _id?: string
  agency?: User | string
  fullName: string
  email?: string
  phone?: string
  password?: string
  birthDate?: Date
  verified?: boolean
  verifiedAt?: Date
  active?: boolean
  language?: string
  enableEmailNotifications?: boolean
  avatar?: string
  bio?: string
  location?: string
  type?: string
  blacklisted?: boolean
  payLater?: boolean
  accessToken?: string
  checked?: boolean
  customerId?: string
}

export interface Option {
  _id: string
  name?: string
  image?: string
}

export interface LocationValue {
  language: string
  value?: string
  name?: string
}

export interface Location {
  _id: string
  country?: Country
  longitude?: number
  latitude?: number
  name?: string
  values?: LocationValue[]
  image?: string
  parentLocation?: Location
}

export interface Country {
  _id: string
  name?: string
  values?: LocationValue[]
}

export interface CountryInfo extends Country {
  locations?: Location[]
}

export interface Property {
  _id: string
  name: string
  type: PropertyType
  agency: User
  description: string
  available: boolean
  image: string
  images?: string[]
  bedrooms: number
  bathrooms: number
  kitchens: number
  parkingSpaces: number
  size?: number
  petsAllowed: boolean
  furnished: boolean
  aircon: boolean
  minimumAge: number
  location: Location
  address?: string
  latitude?: number
  longitude?: number
  price: number
  hidden: boolean
  cancellation: number
  rentalTerm: RentalTerm
  blockOnPay?: boolean
  [propKey: string]: any
}

export interface CreatePropertyPayload {
  name: string
  agency: string
  type: string
  description: string
  image: string
  images?: string[]
  available: boolean
  bedrooms: number
  bathrooms: number
  kitchens: number
  parkingSpaces: number
  size?: number
  petsAllowed: boolean
  furnished: boolean
  aircon: boolean
  minimumAge: number
  location?: string
  address: string
  latitude?: number
  longitude?: number
  price: number
  hidden: boolean
  cancellation: number
  rentalTerm: string
  blockOnPay?: boolean
}

export interface UpdatePropertyPayload extends CreatePropertyPayload {
  _id: string
}

export interface Notification {
  _id: string
  user: string
  message: string
  booking?: string
  isRead?: boolean
  checked?: boolean
  createdAt?: Date
}

export interface NotificationCounter {
  _id: string
  user: string
  count: number
}

export interface ResultData<T> {
  pageInfo: { totalRecords: number }
  resultData: T[]
}

export type Result<T> = [ResultData<T>] | [] | undefined | null

export interface Data<T> {
  rows: T[]
  rowCount: number
}

export interface ChangePasswordPayload {
  _id: string
  password: string
  newPassword: string
  strict: boolean
}

export interface UpdateEmailNotificationsPayload {
  _id: string
  enableEmailNotifications: boolean
}

export interface GetPropertiesPayload {
  agencies: string[]
  types?: PropertyType[]
  rentalTerms?: RentalTerm[]
  availability?: Availablity[]
  location?: string
  language?: string
  from?: Date
  to?: Date
}

// BTMS interfaces
export interface FurnishingItem {
  itemKey: string
  quantity: number
  condition: FurnishingCondition
  notes?: string
}

export interface Unit {
  _id?: string
  property: string | Property
  name: string
  rent: number
  securityDeposit: number
  size?: number
  furnishingStatus: FurnishingStatus
  status: UnitStatus
  checklist?: FurnishingItem[]
}

export interface TenantAssignment {
  _id?: string
  user: string | User
  unit: string | Unit
  moveInDate: Date
  contractStart: Date
  contractEnd: Date
  active: boolean
}

export interface RentEntry {
  _id?: string
  unit: string | Unit
  tenant: string | TenantAssignment
  period: string
  dueDate: Date
  amount: number
  status: RentStatus
  paidAmount?: number
  paidAt?: Date
}

export interface MaintenanceTicket {
  _id?: string
  property: string | Property
  unit: string | Unit
  category: string
  description: string
  priority: MaintenancePriority
  status: MaintenanceStatus
  cost?: number
  createdBy: string | User
  createdAt: Date
  closedAt?: Date
}

export interface GetPublicUnitsPayload {
  location?: string
  minRent?: number
  maxRent?: number
  furnishingStatus?: FurnishingStatus[]
  page?: number
  size?: number
}

export interface ManagerDashboard {
  totalProperties: number
  totalUnits: number
  occupiedUnits: number
  vacantUnits: number
  monthlyRentDue: number
  rentCollected: number
  overdueCount: number
  openMaintenanceCount: number
}

export interface TenantDashboard {
  tenant: TenantAssignment
  unit: Unit
  property: Property
  currentRentDue?: RentEntry
  rentHistory: RentEntry[]
  openMaintenanceTickets: MaintenanceTicket[]
}

export interface UpdateLanguagePayload {
  id: string
  language: string
}

export interface GetUsersBody {
  user: string
  types: UserType[]
}

export interface PropertyOptions {
  cancellation?: boolean
}

export interface CreatePaymentPayload {
  amount: number
  /**
   * Three-letter ISO currency code, in lowercase.
   * Must be a supported currency: https://docs.stripe.com/currencies
   *
   * @type {string}
   */
  currency: string
  /**
   * The IETF language tag of the locale Checkout is displayed in. If blank or auto, the browser's locale is used.
   *
   * @type {string}
   */
  locale: string
  receiptEmail: string
  customerName: string
  name: string
  description?: string
}

export interface CreatePayPalOrderPayload {
  bookingId: string
  amount: number
  currency: string
  name: string
  description: string
}

export interface PaymentResult {
  sessionId?: string
  paymentIntentId?: string
  customerId: string
  clientSecret: string | null
}

export interface SendEmailPayload {
  from: string
  to: string
  subject: string
  message: string
  isContactForm: boolean
}

// 
// React types
//
export type DataEvent<T> = (data?: Data<T>) => void

export interface StatusFilterItem {
  label: string
  value: BookingStatus
  checked?: boolean
}

export interface PropertyFilter {
  location: Location
  from: Date
  to: Date
}

export type PropertyFilterSubmitEvent = (filter: PropertyFilter) => void
