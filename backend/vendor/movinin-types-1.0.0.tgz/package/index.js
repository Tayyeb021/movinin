export var UserType;
(function (UserType) {
    UserType["Admin"] = "ADMIN";
    UserType["Agency"] = "AGENCY";
    UserType["User"] = "USER";
    UserType["Tenant"] = "TENANT";
})(UserType || (UserType = {}));
// BTMS enums
export var UnitStatus;
(function (UnitStatus) {
    UnitStatus["Vacant"] = "VACANT";
    UnitStatus["Occupied"] = "OCCUPIED";
    UnitStatus["UnderMaintenance"] = "UNDER_MAINTENANCE";
})(UnitStatus || (UnitStatus = {}));
export var FurnishingStatus;
(function (FurnishingStatus) {
    FurnishingStatus["Unfurnished"] = "UNFURNISHED";
    FurnishingStatus["SemiFurnished"] = "SEMI_FURNISHED";
    FurnishingStatus["FullyFurnished"] = "FULLY_FURNISHED";
})(FurnishingStatus || (FurnishingStatus = {}));
export var FurnishingCondition;
(function (FurnishingCondition) {
    FurnishingCondition["New"] = "NEW";
    FurnishingCondition["Good"] = "GOOD";
    FurnishingCondition["NeedsRepair"] = "NEEDS_REPAIR";
})(FurnishingCondition || (FurnishingCondition = {}));
export var RentStatus;
(function (RentStatus) {
    RentStatus["Pending"] = "PENDING";
    RentStatus["Paid"] = "PAID";
    RentStatus["Partial"] = "PARTIAL";
    RentStatus["Overdue"] = "OVERDUE";
})(RentStatus || (RentStatus = {}));
export var MaintenancePriority;
(function (MaintenancePriority) {
    MaintenancePriority["Low"] = "LOW";
    MaintenancePriority["Medium"] = "MEDIUM";
    MaintenancePriority["High"] = "HIGH";
})(MaintenancePriority || (MaintenancePriority = {}));
export var MaintenanceStatus;
(function (MaintenanceStatus) {
    MaintenanceStatus["Open"] = "OPEN";
    MaintenanceStatus["InProgress"] = "IN_PROGRESS";
    MaintenanceStatus["Completed"] = "COMPLETED";
})(MaintenanceStatus || (MaintenanceStatus = {}));
export var AppType;
(function (AppType) {
    AppType["Admin"] = "ADMIN";
    AppType["Frontend"] = "FRONTEND";
})(AppType || (AppType = {}));
export var PropertyType;
(function (PropertyType) {
    PropertyType["Apartment"] = "APARTMENT";
    PropertyType["Commercial"] = "COMMERCIAL";
    PropertyType["Farm"] = "FARM";
    PropertyType["House"] = "HOUSE";
    PropertyType["Industrial"] = "INDUSTRIAL";
    PropertyType["Plot"] = "PLOT";
    PropertyType["Townhouse"] = "TOWNHOUSE";
})(PropertyType || (PropertyType = {}));
export var BookingStatus;
(function (BookingStatus) {
    BookingStatus["Void"] = "VOID";
    BookingStatus["Pending"] = "PENDING";
    BookingStatus["Deposit"] = "DEPOSIT";
    BookingStatus["Paid"] = "PAID";
    BookingStatus["Reserved"] = "RESERVED";
    BookingStatus["Cancelled"] = "CANCELLED";
})(BookingStatus || (BookingStatus = {}));
export var RecordType;
(function (RecordType) {
    RecordType["Admin"] = "ADMIN";
    RecordType["Agency"] = "AGENCY";
    RecordType["User"] = "USER";
    RecordType["Tenant"] = "TENANT";
    RecordType["Property"] = "PROPERTY";
    RecordType["Location"] = "LOCATION";
    RecordType["Country"] = "COUNTRY";
})(RecordType || (RecordType = {}));
export var Availablity;
(function (Availablity) {
    Availablity["Available"] = "AVAILABLE";
    Availablity["Unavailable"] = "UNAVAILABLE";
})(Availablity || (Availablity = {}));
export var RentalTerm;
(function (RentalTerm) {
    RentalTerm["Monthly"] = "MONTHLY";
    RentalTerm["Weekly"] = "WEEKLY";
    RentalTerm["Daily"] = "DAILY";
    RentalTerm["Yearly"] = "YEARLY";
})(RentalTerm || (RentalTerm = {}));
export var PaymentGateway;
(function (PaymentGateway) {
    PaymentGateway["PayPal"] = "payPal";
    PaymentGateway["Stripe"] = "stripe";
})(PaymentGateway || (PaymentGateway = {}));
export var SocialSignInType;
(function (SocialSignInType) {
    SocialSignInType["Facebook"] = "facebook";
    SocialSignInType["Apple"] = "apple";
    SocialSignInType["Google"] = "google";
})(SocialSignInType || (SocialSignInType = {}));
